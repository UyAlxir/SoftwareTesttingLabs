package com.example;

public class NoTestCoverage {
  
  public int returnOne() {
    return 1;
  }

}
